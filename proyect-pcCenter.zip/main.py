from form.registro_form import FormularioRegistro

if __name__ == "__main__":
    app = FormularioRegistro()
    app.mainloop()
